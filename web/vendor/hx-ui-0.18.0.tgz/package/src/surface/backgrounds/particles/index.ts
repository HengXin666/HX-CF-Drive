// 行为规格参照 docs/research/catalog/backgrounds-1.md 与 backgrounds-2.md 的 Backgrounds 条目, 实现为 HX 自有. particles 路出口, 每件落盘时追加一行.
export { Particles, type ParticlesProps } from "./Particles";
export { Galaxy, type GalaxyProps } from "./Galaxy";
export { Hyperspeed, type HyperspeedProps } from "./Hyperspeed";
export { Antigravity, type AntigravityProps } from "./Antigravity";
export { Ballpit, type BallpitProps } from "./Ballpit";
export { GradientBlinds, type GradientBlindsProps } from "./GradientBlinds";
export { MagnetLines, type MagnetLinesProps } from "./MagnetLines";
export { GhostFibers, type GhostFibersProps } from "./GhostFibers";
export { AeroShards, type AeroShardsProps } from "./AeroShards";
